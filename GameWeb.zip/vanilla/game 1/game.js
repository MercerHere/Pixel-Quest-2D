const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const UI = {
  coinCounter: document.getElementById("coinCounter"),
  lifeCounter: document.getElementById("lifeCounter"),
  checkpointLabel: document.getElementById("checkpointLabel"),
  timerLabel: document.getElementById("timerLabel"),
  objectiveText: document.getElementById("objectiveText"),
  pauseButton: document.getElementById("pauseButton"),
  restartButton: document.getElementById("restartButton"),
  messageBanner: document.getElementById("messageBanner"),
  pauseOverlay: document.getElementById("pauseOverlay"),
  resumeButton: document.getElementById("resumeButton"),
  pauseRestartButton: document.getElementById("pauseRestartButton"),
  gameOverOverlay: document.getElementById("gameOverOverlay"),
  gameOverStats: document.getElementById("gameOverStats"),
  gameOverRestartButton: document.getElementById("gameOverRestartButton"),
  winOverlay: document.getElementById("winOverlay"),
  winStats: document.getElementById("winStats"),
  playAgainButton: document.getElementById("playAgainButton"),
  touchButtons: Array.from(document.querySelectorAll("#touchControls [data-action]"))
};

const CONFIG = {
  gravity: 0.7,
  jumpPower: 17,
  moveSpeed: 5,
  maxFallSpeed: 18,
  baseWorldHeight: 770,
  coyoteFrames: 8,
  jumpBufferFrames: 8,
  maxLives: 3,
  respawnInvulnerabilityFrames: 70
};

const world = {
  width: 3000,
  height: CONFIG.baseWorldHeight,
  cameraX: 0
};

const input = {
  left: false,
  right: false,
  jumpBufferFrames: 0
};

const platforms = [
  { x: 0, y: 700, width: 900, height: 70 },
  { x: 980, y: 700, width: 520, height: 70 },
  { x: 1600, y: 700, width: 460, height: 70 },
  { x: 2140, y: 700, width: 860, height: 70 },
  { x: 330, y: 560, width: 220, height: 20 },
  { x: 660, y: 490, width: 210, height: 20 },
  { x: 980, y: 430, width: 220, height: 20 },
  { x: 1340, y: 520, width: 210, height: 20 },
  { x: 1720, y: 470, width: 220, height: 20 },
  { x: 2060, y: 410, width: 230, height: 20 }
];

const coinBlueprint = [
  { x: 380, y: 515, size: 20 },
  { x: 730, y: 445, size: 20 },
  { x: 1060, y: 385, size: 20 },
  { x: 1410, y: 475, size: 20 },
  { x: 1780, y: 425, size: 20 },
  { x: 2140, y: 365, size: 20 },
  { x: 2460, y: 650, size: 20 },
  { x: 2820, y: 650, size: 20 }
];

const obstacles = [
  { x: 560, y: 680, width: 80, height: 20 },
  { x: 1210, y: 680, width: 90, height: 20 },
  { x: 1950, y: 680, width: 90, height: 20 },
  { x: 2320, y: 680, width: 90, height: 20 }
];

const checkpoints = [
  { id: "start", x: 130, y: 610, width: 24, height: 90, spawnX: 90, spawnY: 560, label: "Start" },
  { id: "ridge", x: 1080, y: 340, width: 24, height: 90, spawnX: 1030, spawnY: 366, label: "Ridge" },
  { id: "bridge", x: 1810, y: 380, width: 24, height: 90, spawnX: 1760, spawnY: 406, label: "Bridge" },
  { id: "gate", x: 2440, y: 610, width: 24, height: 90, spawnX: 2390, spawnY: 636, label: "Gate" }
];

const cloudBlueprint = [
  { x: 520, y: 112, scale: 1.05, speed: 0.14 },
  { x: 1040, y: 164, scale: 1.3, speed: 0.18 },
  { x: 1600, y: 98, scale: 0.92, speed: 0.16 },
  { x: 2200, y: 146, scale: 1.1, speed: 0.15 }
];

const door = {
  x: 2880,
  y: 624,
  width: 64,
  height: 76,
  open: false
};

const player = {
  x: checkpoints[0].spawnX,
  y: checkpoints[0].spawnY,
  width: 56,
  height: 64,
  vx: 0,
  vy: 0,
  onGround: false,
  facing: 1,
  state: "idle",
  coyoteFrames: 0,
  invulnerableFrames: 0
};

const state = {
  won: false,
  paused: false,
  gameOver: false,
  coinScore: 0,
  lives: CONFIG.maxLives,
  deaths: 0,
  checkpointId: checkpoints[0].id,
  elapsedMs: 0,
  bannerText: "",
  bannerUntil: 0
};

let coins = [];
let coinPickupEffects = [];
let floatingTexts = [];
let lastFrameTime = 0;

function setup() {
  resizeCanvas();
  window.addEventListener("resize", resizeCanvas);
  window.addEventListener("blur", clearMovementInput);
  document.addEventListener("visibilitychange", handleVisibilityChange);
  setupInput();
  setupButtons();
  resetRun();
  requestAnimationFrame(gameLoop);
}

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  world.height = Math.max(CONFIG.baseWorldHeight, canvas.height);
}

function setupInput() {
  document.addEventListener("keydown", (event) => {
    if (event.code === "ArrowRight" || event.code === "KeyD") input.right = true;
    if (event.code === "ArrowLeft" || event.code === "KeyA") input.left = true;

    if (event.code === "ArrowUp" || event.code === "KeyW" || event.code === "Space") {
      queueJump();
      event.preventDefault();
    }

    if (event.code === "Escape" || event.code === "KeyP") {
      togglePause();
      event.preventDefault();
    }

    if (event.code === "KeyR") {
      resetRun();
    }

    if ((event.code === "Enter" || event.code === "NumpadEnter") && (state.won || state.gameOver)) {
      resetRun();
    }
  });

  document.addEventListener("keyup", (event) => {
    if (event.code === "ArrowRight" || event.code === "KeyD") input.right = false;
    if (event.code === "ArrowLeft" || event.code === "KeyA") input.left = false;
  });

  for (const button of UI.touchButtons) {
    const action = button.dataset.action;

    button.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      button.classList.add("is-held");
      if (event.pointerId !== undefined) button.setPointerCapture(event.pointerId);
      setTouchAction(action, true);
    });

    const clearAction = (event) => {
      event.preventDefault();
      button.classList.remove("is-held");
      setTouchAction(action, false);
      if (event.pointerId !== undefined && button.hasPointerCapture(event.pointerId)) {
        button.releasePointerCapture(event.pointerId);
      }
    };

    button.addEventListener("pointerup", clearAction);
    button.addEventListener("pointercancel", clearAction);
    button.addEventListener("pointerleave", clearAction);
  }
}

function setupButtons() {
  UI.pauseButton.addEventListener("click", togglePause);
  UI.restartButton.addEventListener("click", resetRun);
  UI.resumeButton.addEventListener("click", () => setPaused(false));
  UI.pauseRestartButton.addEventListener("click", resetRun);
  UI.gameOverRestartButton.addEventListener("click", resetRun);
  UI.playAgainButton.addEventListener("click", resetRun);
}

function setTouchAction(action, active) {
  if (action === "left") input.left = active;
  if (action === "right") input.right = active;
  if (action === "jump" && active) queueJump();
}

function queueJump() {
  input.jumpBufferFrames = CONFIG.jumpBufferFrames;
}

function clearMovementInput() {
  input.left = false;
  input.right = false;
  for (const button of UI.touchButtons) {
    button.classList.remove("is-held");
  }
}

function handleVisibilityChange() {
  if (document.hidden) {
    clearMovementInput();
    if (!state.won && !state.gameOver) setPaused(true);
  }
}

function resetRun() {
  coins = coinBlueprint.map((coin) => ({
    ...coin,
    width: coin.size,
    height: coin.size,
    collected: false
  }));

  coinPickupEffects = [];
  floatingTexts = [];
  state.won = false;
  state.paused = false;
  state.gameOver = false;
  state.coinScore = 0;
  state.lives = CONFIG.maxLives;
  state.deaths = 0;
  state.checkpointId = checkpoints[0].id;
  state.elapsedMs = 0;
  state.bannerText = "";
  state.bannerUntil = 0;
  door.open = false;
  input.jumpBufferFrames = 0;
  lastFrameTime = 0;

  placePlayerAtCheckpoint(checkpoints[0], false);
  syncUI();
  syncOverlays();
  renderBanner();
  updateObjectiveText();
}

function placePlayerAtCheckpoint(checkpoint, grantInvulnerability) {
  player.x = checkpoint.spawnX;
  player.y = checkpoint.spawnY;
  player.vx = 0;
  player.vy = 0;
  player.onGround = false;
  player.state = "idle";
  player.coyoteFrames = 0;
  player.invulnerableFrames = grantInvulnerability ? CONFIG.respawnInvulnerabilityFrames : 0;
  world.cameraX = clamp(checkpoint.spawnX - canvas.width * 0.2, 0, world.width - canvas.width);
}

function loseLife() {
  if (player.invulnerableFrames > 0 || state.won || state.gameOver) return;

  state.lives -= 1;
  state.deaths += 1;
  syncLifeCounter();

  if (state.lives <= 0) {
    triggerGameOver();
    return;
  }

  const checkpoint = getActiveCheckpoint();
  placePlayerAtCheckpoint(checkpoint, true);
  setBanner(`Respawned at ${checkpoint.label}.`);
}

function triggerGameOver() {
  state.gameOver = true;
  state.paused = false;
  clearMovementInput();
  input.jumpBufferFrames = 0;
  UI.gameOverStats.textContent = `You reached ${getActiveCheckpoint().label}, grabbed ${state.coinScore}/${coins.length} coins, and lasted ${formatTime(state.elapsedMs)}.`;
  syncOverlays();
  updateObjectiveText();
  setBanner("Run lost.");
}

function triggerWin() {
  state.won = true;
  state.paused = false;
  clearMovementInput();
  input.jumpBufferFrames = 0;
  UI.winStats.textContent = `Time ${formatTime(state.elapsedMs)}. Deaths ${state.deaths}. Coins ${state.coinScore}/${coins.length}.`;
  syncOverlays();
  updateObjectiveText();
  setBanner("Portal cleared.");
}

function togglePause() {
  if (state.won || state.gameOver) return;
  setPaused(!state.paused);
}

function setPaused(nextValue) {
  if (state.won || state.gameOver) return;
  state.paused = nextValue;
  if (state.paused) clearMovementInput();
  syncOverlays();
}

function syncOverlays() {
  toggleOverlay(UI.pauseOverlay, state.paused && !state.won && !state.gameOver);
  toggleOverlay(UI.gameOverOverlay, state.gameOver);
  toggleOverlay(UI.winOverlay, state.won);
  UI.pauseButton.textContent = state.paused ? "Resume" : "Pause";
}

function toggleOverlay(element, visible) {
  element.classList.toggle("show", visible);
  element.setAttribute("aria-hidden", String(!visible));
}

function update(deltaMs, now) {
  renderBanner(now);

  if (state.paused || state.gameOver || state.won) {
    syncTimer();
    return;
  }

  state.elapsedMs += deltaMs;
  syncTimer();

  if (player.invulnerableFrames > 0) player.invulnerableFrames -= 1;

  if (player.onGround) {
    player.coyoteFrames = CONFIG.coyoteFrames;
  } else if (player.coyoteFrames > 0) {
    player.coyoteFrames -= 1;
  }

  if (input.jumpBufferFrames > 0) input.jumpBufferFrames -= 1;

  player.vx = 0;
  if (input.left && !input.right) {
    player.vx = -CONFIG.moveSpeed;
    player.facing = -1;
  }
  if (input.right && !input.left) {
    player.vx = CONFIG.moveSpeed;
    player.facing = 1;
  }

  if (input.jumpBufferFrames > 0 && player.coyoteFrames > 0) {
    player.vy = -CONFIG.jumpPower;
    player.onGround = false;
    player.coyoteFrames = 0;
    input.jumpBufferFrames = 0;
  }

  player.vy += CONFIG.gravity;
  if (player.vy > CONFIG.maxFallSpeed) player.vy = CONFIG.maxFallSpeed;

  moveAndCollide();
  updatePlayerState();
  updateCheckpoints();
  collectCoins(now);
  updateCoinAnimations();
  updateDoorState();
  checkHazards();
  checkWin();
  updateObjectiveText();
  updateCamera();
}

function moveAndCollide() {
  player.x += player.vx;
  resolveHorizontalCollisions();

  player.y += player.vy;
  resolveVerticalCollisions();

  if (player.x < 0) player.x = 0;
  if (player.x + player.width > world.width) player.x = world.width - player.width;

  if (player.y > world.height + 260) loseLife();
}

function resolveHorizontalCollisions() {
  for (const platform of platforms) {
    if (!rectIntersect(player, platform)) continue;
    if (player.vx > 0) player.x = platform.x - player.width;
    if (player.vx < 0) player.x = platform.x + platform.width;
  }
}

function resolveVerticalCollisions() {
  player.onGround = false;

  for (const platform of platforms) {
    if (!rectIntersect(player, platform)) continue;

    if (player.vy > 0) {
      player.y = platform.y - player.height;
      player.vy = 0;
      player.onGround = true;
    } else if (player.vy < 0) {
      player.y = platform.y + platform.height;
      player.vy = 0;
    }
  }
}

function updatePlayerState() {
  if (!player.onGround && player.vy > 0.3) {
    player.state = "fall";
    return;
  }

  if (!player.onGround && player.vy < -0.3) {
    player.state = "jump";
    return;
  }

  if (Math.abs(player.vx) > 0.1) {
    player.state = "run";
    return;
  }

  player.state = "idle";
}

function updateCheckpoints() {
  const playerBounds = {
    x: player.x + 10,
    y: player.y,
    width: player.width - 20,
    height: player.height
  };

  for (const checkpoint of checkpoints) {
    if (checkpoint.id === state.checkpointId) continue;
    if (!rectIntersect(playerBounds, checkpoint)) continue;

    state.checkpointId = checkpoint.id;
    UI.checkpointLabel.textContent = checkpoint.label;
    setBanner(`Checkpoint: ${checkpoint.label}`);
  }
}

function collectCoins(now) {
  for (const coin of coins) {
    if (coin.collected) continue;

    if (rectIntersect(player, coin)) {
      coin.collected = true;
      state.coinScore += 1;
      createCoinPickupEffects(coin, now);
      updateCoinCounter();
    }
  }
}

function updateDoorState() {
  const wasOpen = door.open;
  door.open = state.coinScore === coins.length;

  if (door.open && !wasOpen) {
    setBanner("Portal unlocked.");
  }
}

function checkHazards() {
  if (player.invulnerableFrames > 0) return;

  for (const obstacle of obstacles) {
    if (rectIntersect(player, obstacle)) {
      loseLife();
      return;
    }
  }
}

function checkWin() {
  if (state.gameOver) return;

  if (door.open && rectIntersect(player, door)) {
    triggerWin();
  }
}

function updateCamera() {
  const targetX = player.x + player.width * 0.5 - canvas.width * 0.5;
  world.cameraX = clamp(targetX, 0, Math.max(0, world.width - canvas.width));
}

function updateCoinAnimations() {
  for (let index = coinPickupEffects.length - 1; index >= 0; index -= 1) {
    coinPickupEffects[index].life -= 1;
    if (coinPickupEffects[index].life <= 0) {
      coinPickupEffects.splice(index, 1);
    }
  }

  for (let index = floatingTexts.length - 1; index >= 0; index -= 1) {
    const textFx = floatingTexts[index];
    textFx.y += textFx.vy;
    textFx.life -= 1;

    if (textFx.life <= 0) {
      floatingTexts.splice(index, 1);
    }
  }
}

function draw(now) {
  drawBackground(now);

  ctx.save();
  ctx.translate(-world.cameraX, 0);

  drawCheckpoints(now);
  drawPlatforms();
  drawCoins(now);
  drawCoinPickupEffects();
  drawFloatingTexts();
  drawObstacles(now);
  drawDoor(now);
  drawDoorPrompt();
  drawPlayer(now);

  ctx.restore();
}

function drawBackground(now) {
  const sky = ctx.createLinearGradient(0, 0, 0, canvas.height);
  sky.addColorStop(0, "#73c5fb");
  sky.addColorStop(0.7, "#a7daf8");
  sky.addColorStop(1, "#d6eefb");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = "rgba(255, 255, 255, 0.15)";
  ctx.fillRect(0, 460, canvas.width, 210);

  for (const cloud of cloudBlueprint) {
    const x = ((cloud.x - world.cameraX * cloud.speed + now * 0.01 * cloud.speed) % (canvas.width + 320)) - 160;
    drawCloud(x, cloud.y, cloud.scale);
  }

  const farOffset = -(world.cameraX * 0.12) % 360;
  for (let x = farOffset - 360; x < canvas.width + 360; x += 360) {
    drawHill(x, 715, 220, 95, "#b0d58c");
  }

  const midOffset = -(world.cameraX * 0.24) % 320;
  for (let x = midOffset - 320; x < canvas.width + 320; x += 320) {
    drawHill(x, 778, 210, 136, "#7db15b");
  }

  const nearOffset = -(world.cameraX * 0.34) % 280;
  for (let x = nearOffset - 280; x < canvas.width + 280; x += 280) {
    drawHill(x, 820, 180, 86, "#5f9748");
  }

  ctx.fillStyle = "#4f8e3c";
  ctx.fillRect(0, 700, canvas.width, canvas.height - 700);

  ctx.fillStyle = "#346a27";
  ctx.fillRect(0, 700, canvas.width, 7);
}

function drawCloud(x, y, scale) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
  ctx.beginPath();
  ctx.arc(0, 8, 24, 0, Math.PI * 2);
  ctx.arc(28, 0, 28, 0, Math.PI * 2);
  ctx.arc(58, 10, 24, 0, Math.PI * 2);
  ctx.arc(26, 16, 30, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawHill(x, baseY, width, height, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x, baseY);
  ctx.quadraticCurveTo(x + width * 0.25, baseY - height, x + width * 0.5, baseY - height * 0.65);
  ctx.quadraticCurveTo(x + width * 0.75, baseY - height * 1.1, x + width, baseY);
  ctx.closePath();
  ctx.fill();
}

function drawPlatforms() {
  for (const platform of platforms) {
    const baseGradient = ctx.createLinearGradient(platform.x, platform.y, platform.x, platform.y + platform.height);
    baseGradient.addColorStop(0, platform.y > 650 ? "#58a03d" : "#63b045");
    baseGradient.addColorStop(1, platform.y > 650 ? "#44752f" : "#4f8837");
    ctx.fillStyle = baseGradient;
    ctx.fillRect(platform.x, platform.y, platform.width, platform.height);

    ctx.fillStyle = "#2f5e20";
    ctx.fillRect(platform.x, platform.y, platform.width, 6);
  }
}

function drawCheckpoints(now) {
  for (const checkpoint of checkpoints) {
    const active = checkpoint.id === state.checkpointId;
    const sway = Math.sin(now * 0.01 + checkpoint.x * 0.01) * 4;

    ctx.fillStyle = active ? "#fff199" : "#ffffff";
    ctx.fillRect(checkpoint.x, checkpoint.y, 6, checkpoint.height);

    ctx.beginPath();
    ctx.moveTo(checkpoint.x + 6, checkpoint.y + 10);
    ctx.lineTo(checkpoint.x + 34 + sway, checkpoint.y + 20);
    ctx.lineTo(checkpoint.x + 6, checkpoint.y + 30);
    ctx.closePath();
    ctx.fillStyle = active ? "#f4a340" : "#4aa3ff";
    ctx.fill();
  }
}

function drawCoins(now) {
  for (const coin of coins) {
    if (coin.collected) continue;

    const bob = Math.sin(now * 0.008 + coin.x * 0.02) * 4;
    const cx = coin.x + coin.size * 0.5;
    const cy = coin.y + coin.size * 0.5 + bob;
    const radius = coin.size * 0.5;

    ctx.beginPath();
    ctx.fillStyle = "#ffd84d";
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.fill();

    ctx.lineWidth = 2;
    ctx.strokeStyle = "rgba(255, 246, 176, 0.9)";
    ctx.beginPath();
    ctx.arc(cx, cy, radius * 0.68, 0, Math.PI * 2);
    ctx.stroke();

    ctx.beginPath();
    ctx.fillStyle = "#fff4af";
    ctx.arc(cx - 3, cy - 4, radius * 0.34, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawDoor(now) {
  if (door.open) {
    const pulse = 0.5 + Math.sin(now * 0.01) * 0.5;
    ctx.fillStyle = `rgba(87, 215, 255, ${0.24 + pulse * 0.26})`;
    ctx.fillRect(door.x - 10, door.y - 10, door.width + 20, door.height + 20);
  }

  ctx.fillStyle = door.open ? "#46c7ff" : "#77522e";
  ctx.fillRect(door.x, door.y, door.width, door.height);

  ctx.fillStyle = door.open ? "#e7fbff" : "#a27f55";
  ctx.fillRect(door.x + 8, door.y + 10, door.width - 16, door.height - 14);

  ctx.fillStyle = door.open ? "#1d6b97" : "#54412d";
  ctx.fillRect(door.x + 22, door.y + 10, 10, door.height - 20);

  ctx.fillStyle = door.open ? "#fff6a5" : "#2f2112";
  ctx.fillRect(door.x + door.width - 14, door.y + door.height * 0.5, 5, 5);
}

function drawDoorPrompt() {
  if (!door.open) return;

  const playerDistance = Math.abs((player.x + player.width * 0.5) - (door.x + door.width * 0.5));
  if (playerDistance > 220) return;

  ctx.fillStyle = "rgba(0, 0, 0, 0.76)";
  ctx.fillRect(door.x - 46, door.y - 46, 156, 28);
  ctx.fillStyle = "#f4feff";
  ctx.font = "bold 14px Arial";
  ctx.textAlign = "center";
  ctx.fillText("Step into the portal", door.x + door.width * 0.5, door.y - 27);
}

function drawObstacles(now) {
  for (const spike of obstacles) {
    const glow = 0.55 + Math.sin(now * 0.02 + spike.x * 0.05) * 0.2;
    const steps = Math.floor(spike.width / 20);

    for (let index = 0; index < steps; index += 1) {
      const x = spike.x + index * 20;
      ctx.beginPath();
      ctx.moveTo(x, spike.y + spike.height);
      ctx.lineTo(x + 10, spike.y);
      ctx.lineTo(x + 20, spike.y + spike.height);
      ctx.closePath();
      ctx.fillStyle = `rgba(220, 43, 34, ${glow})`;
      ctx.fill();
      ctx.strokeStyle = "#7d1411";
      ctx.stroke();
    }
  }
}

function drawPlayer(now) {
  if (player.invulnerableFrames > 0 && Math.floor(player.invulnerableFrames / 6) % 2 === 0) {
    ctx.save();
    ctx.globalAlpha = 0.55;
  }

  const x = player.x;
  const y = player.y;
  const runBob = player.state === "run" ? Math.sin(now * 0.02) * 3 : 0;
  const bodyColor = player.state === "fall" ? "#eb8d34" : "#f2a146";
  const scarfColor = player.state === "jump" ? "#f4e46e" : "#61c8ff";

  ctx.fillStyle = bodyColor;
  ctx.fillRect(x + 9, y + 16 + runBob * 0.2, 38, 40);

  ctx.fillStyle = "#f6bf73";
  ctx.fillRect(x + 10, y + 6, 36, 20);

  ctx.fillStyle = scarfColor;
  ctx.fillRect(x + 14, y + 26, 28, 6);

  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(x + 22, y + 18, 4, 0, Math.PI * 2);
  ctx.arc(x + 34, y + 18, 4, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#111111";
  ctx.beginPath();
  ctx.arc(x + 22, y + 18, 1.5, 0, Math.PI * 2);
  ctx.arc(x + 34, y + 18, 1.5, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.moveTo(x + 20, y + 28);
  ctx.lineTo(x + 28, y + 24);
  ctx.lineTo(x + 36, y + 28);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = "#a35e1f";
  if (player.facing > 0) {
    ctx.fillRect(x - 12, y + 30 + runBob, 12, 10);
  } else {
    ctx.fillRect(x + player.width, y + 30 + runBob, 12, 10);
  }

  ctx.fillStyle = "#7a4a18";
  ctx.fillRect(x + 12, y + 56, 10, 8);
  ctx.fillRect(x + 32, y + 56, 10, 8);

  if (player.invulnerableFrames > 0 && Math.floor(player.invulnerableFrames / 6) % 2 === 0) {
    ctx.restore();
  }
}

function createCoinPickupEffects(coin) {
  const centerX = coin.x + coin.size * 0.5;
  const centerY = coin.y + coin.size * 0.5;

  coinPickupEffects.push({
    x: centerX,
    y: centerY,
    startSize: coin.size,
    life: 18,
    maxLife: 18
  });

  floatingTexts.push({
    x: centerX,
    y: coin.y,
    vy: -1.2,
    text: "+1",
    life: 36,
    maxLife: 36
  });
}

function drawCoinPickupEffects() {
  for (const fx of coinPickupEffects) {
    const progress = 1 - fx.life / fx.maxLife;
    const scale = 1 - progress * 0.75;
    const alpha = 1 - progress;
    const size = fx.startSize * scale;

    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = "#ffd84d";
    ctx.beginPath();
    ctx.arc(fx.x, fx.y, size * 0.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

function drawFloatingTexts() {
  for (const fx of floatingTexts) {
    const alpha = Math.max(0, fx.life / fx.maxLife);
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = "#fff2a8";
    ctx.font = "bold 18px Arial";
    ctx.textAlign = "center";
    ctx.fillText(fx.text, fx.x, fx.y);
    ctx.restore();
  }
}

function updateCoinCounter() {
  UI.coinCounter.textContent = `${state.coinScore} / ${coins.length}`;
}

function syncLifeCounter() {
  UI.lifeCounter.textContent = `${state.lives} / ${CONFIG.maxLives}`;
}

function syncTimer() {
  UI.timerLabel.textContent = formatTime(state.elapsedMs);
}

function syncUI() {
  updateCoinCounter();
  syncLifeCounter();
  UI.checkpointLabel.textContent = getActiveCheckpoint().label;
  syncTimer();
}

function updateObjectiveText() {
  if (state.won) {
    UI.objectiveText.textContent = "Portal cleared. Restart to chase a faster run.";
    return;
  }

  if (state.gameOver) {
    UI.objectiveText.textContent = "The run ended. Restart and use the checkpoints more aggressively.";
    return;
  }

  if (door.open) {
    UI.objectiveText.textContent = "The portal is open. Reach the glowing gate to finish the run.";
    return;
  }

  const remaining = coins.length - state.coinScore;
  UI.objectiveText.textContent = `Collect ${remaining} more ${remaining === 1 ? "coin" : "coins"} to unlock the portal.`;
}

function setBanner(text, duration = 2200) {
  state.bannerText = text;
  state.bannerUntil = performance.now() + duration;
  renderBanner();
}

function renderBanner(now = performance.now()) {
  const visible = Boolean(state.bannerText) && now < state.bannerUntil;
  UI.messageBanner.textContent = visible ? state.bannerText : "";
  UI.messageBanner.classList.toggle("show", visible);
}

function getActiveCheckpoint() {
  return checkpoints.find((checkpoint) => checkpoint.id === state.checkpointId) || checkpoints[0];
}

function rectIntersect(a, b) {
  return (
    a.x < b.x + b.width &&
    a.x + a.width > b.x &&
    a.y < b.y + b.height &&
    a.y + a.height > b.y
  );
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function formatTime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}

function gameLoop(timestamp) {
  if (!lastFrameTime) lastFrameTime = timestamp;
  const deltaMs = Math.min(32, timestamp - lastFrameTime);
  lastFrameTime = timestamp;

  update(deltaMs, timestamp);
  draw(timestamp);

  requestAnimationFrame(gameLoop);
}

setup();
