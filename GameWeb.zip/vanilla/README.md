# Retro Arcade

To launch this project with XAMPP, follow:

- [XAMPP-SETUP.md](XAMPP-SETUP.md)

Quick start:

1. Put project in `C:\xampp\htdocs\vanilla`
2. Start Apache and MySQL in XAMPP
3. Import `database.sql` in phpMyAdmin
4. Open `http://localhost/vanilla/login.html`
