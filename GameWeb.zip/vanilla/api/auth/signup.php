<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, ['error' => 'Method not allowed']);
}

$input = json_input();
$username = trim((string)($input['username'] ?? ''));
$email = trim((string)($input['email'] ?? ''));
$password = (string)($input['password'] ?? '');

if ($username === '' || $email === '' || $password === '') {
    respond(422, ['error' => 'Username, email, and password are required.']);
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond(422, ['error' => 'Invalid email format.']);
}

if (strlen($password) < 6) {
    respond(422, ['error' => 'Password must be at least 6 characters.']);
}

try {
    $pdo = db();

    $exists = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
    $exists->execute([$email]);

    if ($exists->fetch()) {
        respond(409, ['error' => 'Email already exists.']);
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $insert = $pdo->prepare('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)');
    $insert->execute([$username, $email, $hashedPassword]);

    $userId = (int)$pdo->lastInsertId();

    respond(201, [
        'message' => 'Signup successful',
        'user' => [
            'id' => $userId,
            'username' => $username,
            'email' => $email,
        ],
    ]);
} catch (Throwable $e) {
    respond(500, ['error' => 'Server error during signup.']);
}
