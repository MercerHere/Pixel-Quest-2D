<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, ['error' => 'Method not allowed']);
}

$input = json_input();
$email = trim((string)($input['email'] ?? ''));
$password = (string)($input['password'] ?? '');

if ($email === '' || $password === '') {
    respond(422, ['error' => 'Email and password are required.']);
}

try {
    $pdo = db();

    $query = $pdo->prepare('SELECT id, username, email, password_hash FROM users WHERE email = ? LIMIT 1');
    $query->execute([$email]);
    $user = $query->fetch();

    if (!$user || !password_verify($password, (string)$user['password_hash'])) {
        respond(401, ['error' => 'Invalid email or password.']);
    }

    respond(200, [
        'message' => 'Login successful',
        'user' => [
            'id' => (int)$user['id'],
            'username' => (string)$user['username'],
            'email' => (string)$user['email'],
        ],
    ]);
} catch (Throwable $e) {
    respond(500, ['error' => 'Server error during login.']);
}
