<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, ['error' => 'Method not allowed']);
}

$input = json_input();
$name = trim((string)($input['name'] ?? ''));
$email = trim((string)($input['email'] ?? ''));
$rating = (int)($input['rating'] ?? 0);
$message = trim((string)($input['message'] ?? ''));

if ($name === '' || $email === '' || $message === '' || $rating < 1 || $rating > 5) {
    respond(422, ['error' => 'Invalid feedback payload.']);
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond(422, ['error' => 'Invalid email format.']);
}

try {
    $pdo = db();

    $insert = $pdo->prepare('INSERT INTO feedback (name, email, rating, message) VALUES (?, ?, ?, ?)');
    $insert->execute([$name, $email, $rating, $message]);

    respond(201, ['message' => 'Feedback submitted']);
} catch (Throwable $e) {
    respond(500, ['error' => 'Server error while saving feedback.']);
}
