<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respond(405, ['error' => 'Method not allowed']);
}

try {
    $pdo = db();

    $sql = '
        SELECT
            u.username AS player,
            COALESCE(SUM(s.score), 0) AS score,
            COUNT(s.id) AS games
        FROM users u
        LEFT JOIN scores s ON s.user_id = u.id
        GROUP BY u.id, u.username
        ORDER BY score DESC, games DESC, player ASC
        LIMIT 25
    ';

    $rows = $pdo->query($sql)->fetchAll();

    respond(200, ['leaderboard' => $rows]);
} catch (Throwable $e) {
    respond(500, ['error' => 'Server error while loading leaderboard.']);
}
