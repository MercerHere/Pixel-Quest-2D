CREATE DATABASE IF NOT EXISTS retro_arcade CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE retro_arcade;

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS feedback (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL,
    rating TINYINT UNSIGNED NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_feedback_rating CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS scores (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    game_key VARCHAR(50) NOT NULL,
    score INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_scores_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO users (username, email, password_hash)
SELECT 'DemoPlayer', 'demo@arcade.com', '$2y$10$j91v3D/P.r2LyFcjIcQBi.PQhL0kEg9G3jv4.jJQ3J8QwKhfvM9nu'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'demo@arcade.com');

INSERT INTO scores (user_id, game_key, score)
SELECT u.id, 'game1', 4200 FROM users u WHERE u.email = 'demo@arcade.com'
UNION ALL
SELECT u.id, 'game2', 3800 FROM users u WHERE u.email = 'demo@arcade.com';
