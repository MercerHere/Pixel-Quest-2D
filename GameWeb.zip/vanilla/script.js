// Retro Arcade - Common JavaScript

const API_BASE = '.';

const GAME_LIBRARY = [
  {
    id: 'game1',
    title: 'Coin Trail',
    description: 'Jump, collect coins, and reach the portal.',
    folder: 'game 1',
    accent: '#ff006e',
    border: '#ffbe0b',
    textColor: 'var(--white)'
  },
  {
    id: 'game2',
    title: 'Snake Arena',
    description: 'Grow your snake and dodge the obstacles.',
    folder: 'game 2',
    accent: '#ffbe0b',
    border: '#00f5ff',
    textColor: 'var(--bg)'
  },
  {
    id: 'game3',
    title: 'Monkey Kong',
    description: 'Climb, survive, and chase the next level.',
    folder: 'game 3',
    accent: '#00f5ff',
    border: '#ff006e',
    textColor: 'var(--white)'
  },
  {
    id: 'game4',
    title: 'Stick Hero',
    description: 'Build the bridge and cross every gap.',
    folder: 'game 4',
    accent: '#ff006e',
    border: '#ffbe0b',
    textColor: 'var(--white)'
  },
  {
    id: 'game5',
    title: 'Pixel Plumber',
    description: 'Run, jump, stomp enemies, and reach the end of the level.',
    folder: 'game 5',
    accent: '#00f5ff',
    border: '#ffbe0b',
    textColor: 'var(--bg)'
  }
];

// Wait for DOM to be ready
document.addEventListener('DOMContentLoaded', function() {
  enforceAuthByPage();
  setupNavigation();
  setupLogoutLinks();
  setupUserDisplay();

  // Setup login form
  setupLoginForm();

  // Setup signup form
  setupSignupForm();

  // Setup feedback form
  setupFeedbackForm();

  // Setup game pages
  setupGameLibrary();
  setupGamePlayer();
  setupGameCountDisplay();

  // Setup leaderboard
  setupLeaderboard();
});

function setupNavigation() {
  const nav = document.querySelector('.nav');
  if (!nav) return;

  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  const publicPages = ['login.html', 'signup.html', 'index.html'];

  if (publicPages.indexOf(currentPage) !== -1) {
    return;
  }

  const activePage = currentPage === 'game-player.html' ? 'library.html' : currentPage;
  const navItems = [
    { href: 'home.html', label: 'Home', icon: '&#127918;' },
    { href: 'library.html', label: 'Library', icon: '&#128218;' },
    { href: 'leaderboard.html', label: 'Leaderboard', icon: '&#127942;' },
    { href: 'feedback.html', label: 'Feedback', icon: '&#128172;' }
  ];

  const linksMarkup = navItems
    .map(function(item) {
      const isActive = item.href === activePage;
      return '<a href="' + item.href + '" class="nav-link' + (isActive ? ' active' : '') + '"><span>' + item.icon + '</span> ' + item.label + '</a>';
    })
    .join('');

  nav.innerHTML = '' +
    '<div class="nav-inner">' +
      '<a href="home.html" class="brand">' +
        '<span class="brand-icon">&#127918;</span>' +
        '<span class="brand-name retro-text neon-pink">RETRO ARCADE</span>' +
      '</a>' +
      '<div class="nav-links">' +
        linksMarkup +
        '<a href="login.html" class="logout"><span>&#8617;</span> Logout</a>' +
      '</div>' +
    '</div>';
}

// Login form handler
function setupLoginForm() {
  const form = document.getElementById('login-form');
  if (!form) return;

  const errorBox = document.getElementById('login-error');

  form.addEventListener('submit', async function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    clearError(errorBox);

    if (!email || !password) {
      showError(errorBox, 'Email and password are required.');
      return;
    }

    try {
      const response = await fetch(API_BASE + '/api/auth/login.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email: email, password: password })
      });

      const payload = await response.json();

      if (!response.ok) {
        showError(errorBox, payload.error || 'Login failed.');
        return;
      }

      localStorage.setItem('retroArcadeUser', JSON.stringify(payload.user));
      window.location.href = './home.html';
    } catch (error) {
      showError(errorBox, 'Cannot connect to server. Start backend and try again.');
    }
  });
}

// Signup form handler
function setupSignupForm() {
  const form = document.getElementById('signup-form');
  if (!form) return;

  const errorBox = document.getElementById('error');

  form.addEventListener('submit', async function(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirm = document.getElementById('confirm').value;

    clearError(errorBox);

    // Check if passwords match
    if (password !== confirm) {
      showError(errorBox, 'Passwords do not match.');
      return;
    }

    try {
      const response = await fetch(API_BASE + '/api/auth/signup.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          username: username,
          email: email,
          password: password
        })
      });

      const payload = await response.json();

      if (!response.ok) {
        showError(errorBox, payload.error || 'Signup failed.');
        return;
      }

      localStorage.setItem('retroArcadeUser', JSON.stringify(payload.user));
      window.location.href = './home.html';
    } catch (error) {
      showError(errorBox, 'Cannot connect to server. Start backend and try again.');
    }
  });
}

// Feedback form handler
function setupFeedbackForm() {
  const form = document.getElementById('feedback-form');
  if (!form) return;

  const formView = document.getElementById('form-view');
  const successView = document.getElementById('success-view');
  const stars = document.querySelectorAll('.star');
  let currentRating = 0;

  // Star rating functionality
  stars.forEach(function(star) {
    star.addEventListener('click', function() {
      currentRating = parseInt(this.dataset.rating);
      updateStars(stars, currentRating);
    });
  });

  // Form submission
  form.addEventListener('submit', async function(event) {
    event.preventDefault();

    if (currentRating < 1) {
      return;
    }

    const formData = new FormData(form);
    const payload = {
      name: String(formData.get('name') || '').trim(),
      email: String(formData.get('email') || '').trim(),
      rating: currentRating,
      message: String(formData.get('message') || '').trim()
    };

    try {
      const response = await fetch(API_BASE + '/api/feedback.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        return;
      }
    } catch (error) {
      return;
    }

    // Show success view
    if (formView) formView.style.display = 'none';
    if (successView) successView.classList.add('show');

    // Reset after 3 seconds
    setTimeout(function() {
      form.reset();
      currentRating = 0;
      updateStars(stars, currentRating);
      if (successView) successView.classList.remove('show');
      if (formView) formView.style.display = 'block';
    }, 3000);
  });
}

// Update star ratings visual state
function updateStars(stars, currentRating) {
  stars.forEach(function(star) {
    const rating = parseInt(star.dataset.rating);
    star.classList.toggle('active', rating <= currentRating);
  });
}

function setupGameLibrary() {
  const container = document.getElementById('game-library');
  if (!container) return;

  container.innerHTML = '';

  GAME_LIBRARY.forEach(function(game, index) {
    const card = document.createElement('article');
    card.className = 'game-card';

    const glowColor = hexToRgb(game.accent, 0.45);
    const shadowColor = glowColor ? 'rgba(' + glowColor + ')' : 'rgba(255, 0, 110, 0.45)';

    card.style.borderColor = game.accent;
    card.style.boxShadow = '0 0 20px ' + shadowColor;

    card.innerHTML = `
      <div class="game-emoji">${getGameEmoji(index)}</div>
      <h2 class="game-title retro-text" style="color: ${game.accent}; text-shadow: 0 0 10px ${shadowColor};">${game.title}</h2>
      <p class="game-desc">${game.description}</p>
      <a class="play-btn" href="game-player.html?game=${game.id}" style="background: ${game.accent}; border-color: ${game.border}; color: ${game.textColor};">
        <span>▶</span>
        <span>Play</span>
      </a>
    `;

    container.appendChild(card);
  });
}

function setupGameCountDisplay() {
  const gameCount = String(GAME_LIBRARY.length);

  const homeStat = document.getElementById('game-count-stat');
  if (homeStat) {
    homeStat.textContent = gameCount;
  }

  const homeCopy = document.getElementById('game-count-copy');
  if (homeCopy) {
    homeCopy.textContent = gameCount;
  }

  const libraryBanner = document.querySelector('.library-banner .terminal span:nth-child(2)');
  if (libraryBanner) {
    libraryBanner.innerHTML = gameCount + ' GAMES LOADED &bull; <span style="color: var(--pink);">READY TO PLAY</span>';
  }

  const playerError = document.getElementById('game-error');
  if (playerError) {
    playerError.textContent = 'Game not found. Return to the library and choose one of the ' + gameCount + ' games.';
  }
}

function setupGamePlayer() {
  const title = document.getElementById('game-title');
  const frame = document.getElementById('game-frame');
  const error = document.getElementById('game-error');
  const panel = document.getElementById('player-panel');
  const openLink = document.getElementById('open-game-link');

  if (!title || !frame || !error || !panel) return;

  const params = new URLSearchParams(window.location.search);
  const selectedId = params.get('game');
  const game = GAME_LIBRARY.find(function(item) {
    return item.id === selectedId;
  });

  if (!game) {
    title.textContent = 'GAME NOT FOUND';
    error.hidden = false;
    panel.hidden = true;
    if (openLink) {
      openLink.setAttribute('aria-disabled', 'true');
      openLink.removeAttribute('href');
    }
    return;
  }

  const gamePath = encodeURI(game.folder + '/index.html');

  title.textContent = game.title;
  frame.src = gamePath;
  if (openLink) {
    openLink.href = gamePath;
  }

  // Keep the embedded game focused so keyboard controls always work.
  const focusGameFrame = function() {
    frame.focus();

    try {
      if (frame.contentWindow) {
        frame.contentWindow.focus();
      }

      const frameDoc = frame.contentDocument;
      if (frameDoc && frameDoc.body) {
        if (!frameDoc.body.hasAttribute('tabindex')) {
          frameDoc.body.setAttribute('tabindex', '-1');
        }
        frameDoc.body.focus();
      }
    } catch (error) {
      // Ignore cross-document focus issues and keep parent page usable.
    }
  };

  const controlCodes = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'Space', 'Enter', 'KeyP', 'KeyX'];
  const shouldForwardControl = function(event) {
    return controlCodes.indexOf(event.code) !== -1 || event.key === 'p' || event.key === 'P' || event.key === 'x' || event.key === 'X';
  };

  frame.setAttribute('tabindex', '0');
  frame.addEventListener('load', function() {
    setTimeout(focusGameFrame, 80);
  });
  panel.addEventListener('pointerdown', focusGameFrame);

  const forwardControlEvent = function(type, event) {
    if (!shouldForwardControl(event)) return;

    focusGameFrame();

    try {
      if (!frame.contentWindow) return;

      const forwardedEvent = new KeyboardEvent(type, {
        key: event.key,
        code: event.code,
        location: event.location,
        repeat: event.repeat,
        ctrlKey: event.ctrlKey,
        shiftKey: event.shiftKey,
        altKey: event.altKey,
        metaKey: event.metaKey,
        bubbles: true,
        cancelable: true
      });

      frame.contentWindow.dispatchEvent(forwardedEvent);
      event.preventDefault();
    } catch (error) {
      // Ignore dispatch issues and preserve parent page behavior.
    }
  };

  window.addEventListener('keydown', function(event) {
    if (document.activeElement === frame) return;
    forwardControlEvent('keydown', event);
  });

  window.addEventListener('keyup', function(event) {
    if (document.activeElement === frame) return;
    forwardControlEvent('keyup', event);
  });

  setTimeout(focusGameFrame, 120);
  document.title = game.title + ' | Retro Arcade';
}

function setupLeaderboard() {
  const podium = document.querySelector('.podium');
  const leaderboard = document.querySelector('.leaderboard');

  if (!podium || !leaderboard) return;

  fetch(API_BASE + '/api/leaderboard.php')
    .then(function(response) {
      return response.json().then(function(payload) {
        return { ok: response.ok, payload: payload };
      });
    })
    .then(function(result) {
      if (!result.ok || !result.payload || !Array.isArray(result.payload.leaderboard)) {
        return;
      }

      const entries = result.payload.leaderboard;
      if (!entries.length) {
        return;
      }

      renderPodium(entries.slice(0, 3), podium);
      renderLeaderboard(entries, leaderboard);
    })
    .catch(function() {
      // Keep static markup if API fails.
    });
}

function renderPodium(topThree, podiumContainer) {
  const order = [1, 0, 2];
  const iconMap = ['👑', '🏆', '🥉'];
  const colorMap = ['var(--gold)', 'var(--pink)', 'var(--cyan)'];

  podiumContainer.innerHTML = '';

  order.forEach(function(idx, slot) {
    const item = topThree[idx];
    if (!item) return;

    const rank = idx + 1;
    const article = document.createElement('article');
    article.className = 'podium-card';
    article.innerHTML = `
      <div class="podium-icon">${iconMap[rank - 1]}</div>
      <div class="podium-rank" style="color: ${colorMap[rank - 1]};">${rank}</div>
      <div class="podium-player">${sanitizeHtml(item.player)}</div>
      <div class="podium-score">${formatNumber(item.score)}</div>
    `;

    if (slot === 1) {
      article.style.transform = 'translateY(-8px)';
    }

    podiumContainer.appendChild(article);
  });
}

function renderLeaderboard(entries, tableContainer) {
  const header = `
    <div class="table-header">
      <div>RANK</div>
      <div>PLAYER</div>
      <div style="text-align: right;">SCORE</div>
      <div style="text-align: right;">GAMES</div>
    </div>
  `;

  const rows = entries
    .map(function(item, index) {
      const rank = index + 1;
      const isTop = rank <= 3;
      const rankIcon = rank === 1 ? '👑' : (rank === 2 ? '🏆' : (rank === 3 ? '🥉' : '📈'));
      const rankColor = rank === 1 ? '#ffbe0b' : (rank === 2 ? '#ff006e' : (rank === 3 ? '#00f5ff' : '#ffbe0b'));

      return `
        <div class="table-row ${isTop ? 'top' : ''}">
          <div class="row-rank" style="color: ${rankColor};">
            <span>${rankIcon}</span>
            <span>${rank}</span>
          </div>
          <div class="row-player" style="color: ${rankColor}; text-shadow: 0 0 5px ${rankColor};">${sanitizeHtml(item.player)}</div>
          <div class="row-score">${formatNumber(item.score)}</div>
          <div class="row-games">${formatNumber(item.games)} plays</div>
        </div>
      `;
    })
    .join('');

  tableContainer.innerHTML = header + rows;
}

function enforceAuthByPage() {
  const publicPages = ['login.html', 'signup.html', 'index.html'];
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  const user = getCurrentUser();

  if (!user && publicPages.indexOf(currentPage) === -1) {
    window.location.href = './login.html';
  }

  if (user && (currentPage === 'login.html' || currentPage === 'signup.html')) {
    window.location.href = './home.html';
  }
}

function setupLogoutLinks() {
  const logoutLinks = document.querySelectorAll('.logout');
  if (!logoutLinks.length) return;

  logoutLinks.forEach(function(link) {
    link.addEventListener('click', function(event) {
      event.preventDefault();
      localStorage.removeItem('retroArcadeUser');
      window.location.href = './login.html';
    });
  });
}

function setupUserDisplay() {
  const user = getCurrentUser();
  if (!user) return;

  const welcomePlayer = document.querySelector('.welcome-player');
  if (welcomePlayer && user.username) {
    welcomePlayer.textContent = String(user.username).toUpperCase();
  }
}

function getCurrentUser() {
  const raw = localStorage.getItem('retroArcadeUser');
  if (!raw) return null;

  try {
    return JSON.parse(raw);
  } catch (error) {
    localStorage.removeItem('retroArcadeUser');
    return null;
  }
}

function clearError(errorBox) {
  if (!errorBox) return;
  errorBox.textContent = '';
  errorBox.classList.remove('show');
}

function showError(errorBox, message) {
  if (!errorBox) return;
  errorBox.textContent = message;
  errorBox.classList.add('show');
}

function sanitizeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatNumber(value) {
  return Number(value || 0).toLocaleString();
}

function getGameEmoji(index) {
  const emojis = ['🪙', '🐍', '🦍', '🪵'];
  return emojis[index] || '🎮';
}

function hexToRgb(hex, alpha) {
  const value = hex.replace('#', '');
  if (value.length !== 6) return null;

  const r = parseInt(value.slice(0, 2), 16);
  const g = parseInt(value.slice(2, 4), 16);
  const b = parseInt(value.slice(4, 6), 16);

  return [r, g, b, alpha].join(', ');
}
