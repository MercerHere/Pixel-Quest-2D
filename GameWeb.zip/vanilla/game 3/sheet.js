const CANVAS_W = 600;
const CANVAS_H = 500;

// ─── DYNAMIC DIFFICULTY CONFIG (level-based scaling)  (update done after a lot of tests)─────────────────────────
// Player gets slower, barrels get faster, spawn interval increases per level
const DIFFICULTY = {
  1: { playerSpeed: 5, barrelRoll: 2.8, barrelDescend: 3.0, throwInterval: 240 },
  2: { playerSpeed: 4.5, barrelRoll: 3.2, barrelDescend: 3.4, throwInterval: 260 },
  3: { playerSpeed: 4, barrelRoll: 3.6, barrelDescend: 3.8, throwInterval: 280 }
};

const GRAVITY = 0.4;
const CLIMB_SPEED = 3;

const PLATFORM_THEMES = [
  { top: "#e8a020", body: "#c47d10", stripe: "#f0c050" },
  { top: "#3dbd5c", body: "#2a8a3e", stripe: "#5de07a" },
  { top: "#4488ee", body: "#2255bb", stripe: "#77aaff" },
  { top: "#dd4444", body: "#aa1111", stripe: "#ff7777" },
  { top: "#aa44dd", body: "#772299", stripe: "#dd77ff" },
  { top: "#dd8833", body: "#aa5511", stripe: "#ffbb55" },
];

const PLAYER_SKINS = [
  { hat: "#f5e642", shirt: "#e03030", pants: "#2244cc" },
  { hat: "#30d060", shirt: "#3088ee", pants: "#cc2299" },
  { hat: "#ff8800", shirt: "#222222", pants: "#cc4400" },
  { hat: "#ffffff", shirt: "#cc2244", pants: "#222244" },
];

const PLATFORMS_DATA = [
  { x: 0,   y: 480, w: 600, h: 20 },//x: horizental
  { x: 0,   y: 400, w: 500, h: 15 },//y vertical
  { x: 100, y: 320, w: 500, h: 15 },//w weight
  { x: 0,   y: 240, w: 500, h: 15 },//h height
  { x: 100, y: 160, w: 500, h: 15 },//radius
  { x: 0,   y: 80,  w: 600, h: 15 },
];

const LADDERS_DATA = [
  { x: 460, y: 400, w: 40, h: 80 },
  { x: 110, y: 320, w: 40, h: 80 },
  { x: 460, y: 240, w: 40, h: 80 },
  { x: 110, y: 160, w: 40, h: 80 },
  { x: 460, y: 80,  w: 40, h: 80 },
];

const BARREL_PATH = [
  { ladderIdx: 4, enterX: 480, landY: 160 },
  { ladderIdx: 3, enterX: 130, landY: 240 },
  { ladderIdx: 2, enterX: 480, landY: 320 },
  { ladderIdx: 1, enterX: 130, landY: 400 },
  { ladderIdx: 0, enterX: 480, landY: 480 },
];

// ─── State ───────────────────────────────────────────────────────────────────
const state = {
  player: { x: 50, y: 440, vx: 0, vy: 0, onGround: false, onLadder: false, facing: 1 },
  barrels: [],
  score: 0,
  lives: 3,
  level: 1,
  throwTimer: 0,
  throwInterval: DIFFICULTY[1].throwInterval,//le temps entre bermil w bermil
  status: "idle",  // idle(not performing an action) | playing | dead | levelup | gameover
  themeIdx: 0,//theme index
  skinIdx: 0,//skin index
  frame: 0,
  overlayTimer: 0,
};

const keys = {};
let rafId = null;//Stores the numeric ID returned by requestAnimationFrame(), so you can stop the animation loop later.

// ─── DOM refs ─────────────────────────────────────────────────────────────────
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");//Gets the drawing engine for a <canvas> element works only for those canvas elements
const scoreVal = document.getElementById("score-val");
const livesDisplay = document.getElementById("lives-display");
const levelVal = document.getElementById("level-val");
const btnStart = document.getElementById("btn-start");

// ─── Sync UI ─────────────────────────────────────────────────────────────────
function syncUI() {
  scoreVal.textContent = state.score;
  levelVal.textContent = state.level;
  const h = "❤️".repeat(state.lives) + "🖤".repeat(Math.max(0, 3 - state.lives));
  livesDisplay.textContent = h;

  const active = state.status === "playing" || state.status === "dead" || state.status === "levelup";// === checks if two values are exactly equal in both value AND data type
  btnStart.disabled = active;
  btnStart.textContent = active ? "▶ PLAYING..." : "▶ START";
}

// ─── Player / Barrel helpers ──────────────────────────────────────────────────
function resetPlayer() {
  state.player = { x: 50, y: 440, vx: 0, vy: 0, onGround: false, onLadder: false, facing: 1 };
  state.barrels = [];
}

// ─── Difficulty helpers ───────────────────────────────────────────────────────
function getCurrentDifficulty() {
  return DIFFICULTY[Math.min(state.level, 3)];
}

function updateDifficulty() {
  const diff = getCurrentDifficulty();
  state.throwInterval = diff.throwInterval;
}

// ─── Drawing helpers ──────────────────────────────────────────────────────────
//DEFINES the path for the shape of the canvas
function roundedRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawBackground() {
  const grad = ctx.createLinearGradient(0, 0, 0, CANVAS_H);
  grad.addColorStop(0, "#0d1b0d");
  grad.addColorStop(0.5, "#112211");
  grad.addColorStop(1, "#1a2e10");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

  ctx.fillStyle = "rgba(255,255,255,0.03)";
  for (let i = 0; i < 60; i++) {
    const sx = (i * 137.5) % CANVAS_W;
    const sy = (i * 79.3) % CANVAS_H;
    const r = 1 + (i % 3);
    ctx.beginPath();
    ctx.arc(sx, sy, r, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.fillStyle = "rgba(34,80,20,0.7)";
  const leaves = [
    [0, 60, 80], [0, 160, 70], [0, 280, 90], [0, 360, 75], [0, 430, 65],
    [520, 80, 80], [540, 200, 70], [510, 310, 90], [530, 400, 75],
  ];
  for (const [lx, ly, sz] of leaves) {
    ctx.beginPath();
    ctx.ellipse(lx, ly, sz, sz * 0.4, -0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(lx, ly + 15, sz * 0.7, sz * 0.3, 0.3, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.strokeStyle = "rgba(80,180,60,0.15)";
  ctx.lineWidth = 2;
  for (let i = 0; i < 8; i++) {
    const vx = 20 + i * 80;
    ctx.beginPath();
    ctx.moveTo(vx, CANVAS_H);
    ctx.bezierCurveTo(vx - 20, CANVAS_H - 150, vx + 30, CANVAS_H - 300, vx - 10, 0);
    ctx.stroke();
  }
}

function drawPlatform(p, theme) {
  ctx.fillStyle = "rgba(0,0,0,0.4)";//related to the function fillRect
  ctx.fillRect(p.x + 4, p.y + 4, p.w, p.h + 4);

  ctx.fillStyle = theme.body;
  ctx.fillRect(p.x, p.y, p.w, p.h);

  ctx.fillStyle = theme.top;
  ctx.fillRect(p.x, p.y, p.w, 6);

  ctx.fillStyle = theme.stripe;
  for (let i = 0; i < p.w; i += 24) {
    ctx.fillRect(p.x + i, p.y + 7, 12, 3);
  }

  ctx.fillStyle = "rgba(0,0,0,0.2)";
  ctx.fillRect(p.x, p.y + p.h - 3, p.w, 3);

  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.lineWidth = 1;
  ctx.strokeRect(p.x, p.y, p.w, p.h);
}

function drawLadder(l) {
  ctx.fillStyle = "#7a5020";
  ctx.fillRect(l.x + 2, l.y, 8, l.h);
  ctx.fillRect(l.x + l.w - 10, l.y, 8, l.h);

  ctx.fillStyle = "#c8901c";
  ctx.fillRect(l.x + 1, l.y, 2, l.h);
  ctx.fillRect(l.x + l.w - 3, l.y, 2, l.h);

  for (let i = 0; i < l.h; i += 13) {
    const g = ctx.createLinearGradient(l.x - 2, 0, l.x + l.w + 2, 0);
    g.addColorStop(0, "#a06828");
    g.addColorStop(0.5, "#e0b050");//couleur des escalier
    g.addColorStop(1, "#a06828");
    ctx.fillStyle = g;
    ctx.fillRect(l.x - 2, l.y + i, l.w + 4, 5);
    ctx.fillStyle = "rgba(255,255,255,0.12)";
    ctx.fillRect(l.x - 2, l.y + i, l.w + 4, 2);
  }
}

function drawBarrel(b) {//b howa lbermil!
  ctx.save();
  ctx.translate(b.x, b.y);
  ctx.rotate(b.angle);

  ctx.fillStyle = "#5c2a08";
  ctx.beginPath();
  ctx.ellipse(0, 0, 14, 14, 0, 0, Math.PI * 2);
  ctx.fill();

  const bg = ctx.createRadialGradient(-4, -4, 1, 0, 0, 14);
  bg.addColorStop(0, "rgba(200,120,40,0.6)");
  bg.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.ellipse(0, 0, 14, 14, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "#b86820";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.ellipse(0, 0, 14, 8, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-14, 0);
  ctx.lineTo(14, 0);
  ctx.strokeStyle = "#d08030";
  ctx.lineWidth = 2;
  ctx.stroke();

  for (let i = -3; i <= 3; i++) {
    ctx.strokeStyle = `rgba(255,${100 + i * 20},0,${0.4 + Math.abs(i) * 0.1})`;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(i * 4, -14);
    ctx.lineTo(i * 4 + 3, -20);
    ctx.stroke();
  }//shadow mta3 lbermil

  ctx.restore();
}

function drawMonkey(throwTimer, throwInterval, frame) {
  const mx = 515, my = 45;
  const isReady = throwTimer > throwInterval / 2;

  ctx.fillStyle = "rgba(0,0,0,0.3)";
  ctx.beginPath();
  ctx.ellipse(mx + 20, my + 60, 25, 8, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#4a2005";
  ctx.fillRect(mx, my + 20, 42, 40);

  ctx.fillStyle = "#7a3a10";
  roundedRect(mx + 4, my - 8, 38, 32, 10);
  ctx.fill();

  ctx.fillStyle = "#c07840";
  roundedRect(mx + 10, my + 4, 26, 18, 8);
  ctx.fill();

  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.ellipse(mx + 14, my + 4, 7, 8, -0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(mx + 28, my + 4, 7, 8, 0.2, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#111";
  ctx.beginPath();
  ctx.ellipse(mx + 14, my + 6, 4, 5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(mx + 28, my + 6, 4, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "rgba(255,255,255,0.7)";
  ctx.beginPath();
  ctx.ellipse(mx + 16, my + 4, 2, 2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(mx + 30, my + 4, 2, 2, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#3a1a02";
  ctx.beginPath(); ctx.arc(mx + 4, my, 10, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(mx + 37, my, 10, 0, Math.PI * 2); ctx.fill();

  ctx.fillStyle = "#c07840";
  ctx.beginPath(); ctx.arc(mx + 4, my, 7, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(mx + 37, my, 7, 0, Math.PI * 2); ctx.fill();

  ctx.fillStyle = "#4a2005";
  if (isReady) {
    ctx.fillRect(mx - 16, my + 26, 18, 8);
    ctx.fillStyle = "#7a3a10";
    ctx.fillRect(mx - 16, my + 26, 18, 4);
  } else {
    ctx.fillRect(mx + 42, my + 26, 18, 8);
    ctx.fillStyle = "#7a3a10";
    ctx.fillRect(mx + 42, my + 26, 18, 4);
  }

  ctx.fillStyle = "#4a2005";
  const legBob = Math.sin(frame * 0.15) * 2;
  ctx.fillRect(mx + 4,  my + 55, 14, 10 + legBob);
  ctx.fillRect(mx + 24, my + 55, 14, 10 - legBob);
}

function drawPlayer(p, skin, frame) {
  const { x, y, facing, onLadder } = p;
  const pw = 28, ph = 38;
  const bob = onLadder ? Math.sin(frame * 0.25) * 2 : 0;

  ctx.fillStyle = "rgba(0,0,0,0.25)";
  ctx.beginPath();
  ctx.ellipse(x + pw / 2, y + ph + 3, 12, 4, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#2244aa";
  ctx.fillRect(x + 4, y + ph * 0.5, pw - 8, ph * 0.5 + bob);

  ctx.fillStyle = skin.shirt;
  ctx.fillRect(x + 2, y + ph * 0.25, pw - 4, ph * 0.35 + bob);

  ctx.fillStyle = "#eec898";
  roundedRect(x + 5, y - 16 + bob, pw - 10, 20, 5);
  ctx.fill();

  ctx.fillStyle = skin.hat;
  ctx.fillRect(x + 4, y - 22 + bob, pw - 8, 8);
  ctx.fillRect(x + 1, y - 16 + bob, pw - 2, 4);

  ctx.fillStyle = "#111";
  const eyeX = facing === 1 ? x + pw - 10 : x + 6;
  ctx.beginPath();
  ctx.ellipse(eyeX, y - 8 + bob, 3, 3, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.7)";
  ctx.beginPath();
  ctx.ellipse(eyeX + facing, y - 9 + bob, 1.5, 1.5, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#eec898";
  const armSwing = Math.sin(frame * 0.2) * 8;
  if (facing === 1) {
    ctx.fillRect(x - 6,      y + ph * 0.28 + armSwing, 10, 6);
    ctx.fillRect(x + pw - 4, y + ph * 0.28 - armSwing, 10, 6);
  } else {
    ctx.fillRect(x + pw - 4, y + ph * 0.28 + armSwing, 10, 6);
    ctx.fillRect(x - 6,      y + ph * 0.28 - armSwing, 10, 6);
  }

  const legSwing = onLadder//permet le mouvement permenant du joueur
    ? Math.sin(frame * 0.25) * 5
    : Math.sin(frame * 0.2) * 4;
  ctx.fillStyle = "#1a2288";
  ctx.fillRect(x + 4,      y + ph - 6 + legSwing, 10, 14);
  ctx.fillRect(x + pw - 14, y + ph - 6 - legSwing, 10, 14);

  ctx.fillStyle = "#333";
  ctx.fillRect(x + 4,      y + ph + 8, 12, 5);
  ctx.fillRect(x + pw - 16, y + ph + 8, 12, 5);
}

function drawHUD(score, lives, level, throwTimer, throwInterval) {
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  roundedRect(6, 6, CANVAS_W - 12, 36, 8);
  ctx.fill();

  ctx.strokeStyle = "rgba(255,200,50,0.3)";
  ctx.lineWidth = 1;
  roundedRect(6, 6, CANVAS_W - 12, 36, 8);
  ctx.stroke();

  ctx.font = "bold 14px monospace";
  ctx.textBaseline ="middle";
  ctx.fillStyle = "#ffd700";
  ctx.fillText(`SCORE: ${score}`, 18, 24);

  const hearts = "❤️".repeat(lives) + "🖤".repeat(Math.max(0, 3 - lives));
  ctx.fillStyle = "#fff";
  ctx.font = "14px monospace";
  ctx.textAlign = "center";
  ctx.fillText(hearts, CANVAS_W / 2, 24);
  ctx.textAlign = "left";

  ctx.font = "bold 14px monospace";
  ctx.fillStyle = "#88ffaa";
  const lvlText = `LVL: ${level}`;
  ctx.fillText(lvlText, CANVAS_W - 18 - ctx.measureText(lvlText).width, 24);

  const barW = 80, barH = 6;
  const barX = CANVAS_W / 2 - barW / 2, barY = 44;
  ctx.fillStyle = "rgba(0,0,0,0.4)";
  ctx.fillRect(barX, barY, barW, barH);
  ctx.fillStyle = "#ff4422";
  ctx.fillRect(barX, barY, barW * (throwTimer / throwInterval), barH);
  ctx.strokeStyle = "rgba(255,100,50,0.5)";
  ctx.lineWidth = 1;
  ctx.strokeRect(barX, barY, barW, barH);
}

function drawTitle(frame) {
  const pulse = 1 + Math.sin(frame * 0.05) * 0.03;
  ctx.save();
  ctx.translate(CANVAS_W / 2, CANVAS_H / 2 - 60);
  ctx.scale(pulse, pulse);
  ctx.font = "bold 52px 'Impact', 'Arial Black', sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.shadowColor = "#ff6600";
  ctx.shadowBlur = 20;
  ctx.fillStyle = "#ff8800";
  ctx.fillText("MONKEY", 0, -20);
  ctx.shadowColor = "#ffcc00";
  ctx.fillStyle = "#ffee00";
  ctx.fillText("KONG", 0, 36);
  ctx.shadowBlur = 0;
  ctx.restore();

  ctx.font = "16px monospace";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillStyle = `rgba(255,255,255,${0.5 + Math.sin(frame * 0.07) * 0.5})`;
  ctx.fillText("PRESS START TO PLAY", CANVAS_W / 2, CANVAS_H / 2 + 30);
  ctx.fillStyle = "rgba(255,200,50,0.7)";
  ctx.font = "12px monospace";
  ctx.fillText("ARROWS TO MOVE  |  UP/DOWN ON LADDER", CANVAS_W / 2, CANVAS_H / 2 + 60);
}

function drawOverlay(status, score, level) {
  if (status !== "dead" && status !== "levelup" && status !== "gameover") return;
  ctx.fillStyle = "rgba(0,0,0,0.75)";
  ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  if (status === "levelup") {
    ctx.font = "bold 48px Impact, Arial Black, sans-serif";
    ctx.fillStyle = "#44ff88";
    ctx.shadowColor = "#00ff44";
    ctx.shadowBlur = 16;
    ctx.fillText("LEVEL UP!", CANVAS_W / 2, CANVAS_H / 2 - 30);
    ctx.shadowBlur = 0;
    ctx.font = "20px monospace";
    ctx.fillStyle = "#ffffaa";
    ctx.fillText(`+${level * 100} PTS`, CANVAS_W / 2, CANVAS_H / 2 + 20);
  } else if (status === "dead") {
    ctx.font = "bold 44px Impact, Arial Black, sans-serif";
    ctx.fillStyle = "#ff3322";
    ctx.shadowColor = "#ff0000";
    ctx.shadowBlur = 16;
    ctx.fillText("OUCH!", CANVAS_W / 2, CANVAS_H / 2 - 20);
    ctx.shadowBlur = 0;
    ctx.font = "16px monospace";
    ctx.fillStyle = "#ffaaaa";
    ctx.fillText("Stay alert!", CANVAS_W / 2, CANVAS_H / 2 + 24);
  } else {
    // Check if this is a WIN (reached level 3 top)
    if (level >= 3 && score >= 200) {
      ctx.font = "bold 48px Impact, Arial Black, sans-serif";
      ctx.fillStyle = "#44ff88";
      ctx.shadowColor = "#00ff44";
      ctx.shadowBlur = 20;
      ctx.fillText("🎉 YOU WIN! 🎉", CANVAS_W / 2, CANVAS_H / 2 - 40);
      ctx.shadowBlur = 0;
      ctx.font = "22px monospace";
      ctx.fillStyle = "#ffd700";
      ctx.fillText(`FINAL SCORE: ${score}`, CANVAS_W / 2, CANVAS_H / 2 + 10);
      ctx.font = "16px monospace";
      ctx.fillStyle = "rgba(100,255,150,0.9)";
      ctx.fillText("Press RESET to play again", CANVAS_W / 2, CANVAS_H / 2 + 46);
    } else {
      ctx.font = "bold 48px Impact, Arial Black, sans-serif";
      ctx.fillStyle = "#ff2200";
      ctx.shadowColor = "#ff0000";
      ctx.shadowBlur = 20;
      ctx.fillText("GAME OVER", CANVAS_W / 2, CANVAS_H / 2 - 40);
      ctx.shadowBlur = 0;
      ctx.font = "22px monospace";
      ctx.fillStyle = "#ffd700";
      ctx.fillText(`FINAL SCORE: ${score}`, CANVAS_W / 2, CANVAS_H / 2 + 10);
      ctx.font = "16px monospace";
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      ctx.fillText("Press RESET to try again", CANVAS_W / 2, CANVAS_H / 2 + 46);
    }
  }
}

// ─── Game loop + keys management ────────────────────────────────────────────────────────────────
function loop() {
  state.frame++;
  const s = state;

  if (s.status === "playing") {
    const p = s.player;
    const diff = getCurrentDifficulty(); // Get current level's difficulty values

    // ── Player input ──
    if (keys["ArrowLeft"] || keys["q"])       { p.vx = -diff.playerSpeed; p.facing = -1; }
    else if (keys["ArrowRight"] || keys["d"]) { p.vx =  diff.playerSpeed; p.facing =  1; }
    else                                       { p.vx = 0; }

    if (p.onLadder) {
      if (keys["ArrowUp"]   || keys["z"]) p.vy = -CLIMB_SPEED;
      else if (keys["ArrowDown"] || keys["s"]) p.vy = CLIMB_SPEED;
      else p.vy = 0;
    } else {
      p.vy += GRAVITY;//illusion mta3 ljoueur yti7
    }

    p.x += p.vx;
    p.y += p.vy;
    p.x = Math.max(0, Math.min(CANVAS_W - 28, p.x));

    // ── Platform collision ──
    p.onGround = false;
    for (const pl of PLATFORMS_DATA) {
      if (p.x + 28 > pl.x && p.x < pl.x + pl.w &&
          p.y + 38 >= pl.y && p.y + 38 <= pl.y + pl.h + 12 &&
          p.vy >= 0) {
        p.y = pl.y - 38;
        p.vy = 0;
        p.onGround = true;
      }
    }

    // ── Ladder detection ──
    p.onLadder = false;
    for (const l of LADDERS_DATA) {
      const cx = p.x + 14, cy = p.y + 19;
      if (cx >= l.x - 8 && cx <= l.x + l.w + 8 && cy >= l.y - 20 && cy <= l.y + l.h + 20) {
        p.onLadder = true;
      }
    }
    if (!p.onLadder && !p.onGround) {
      if (keys["ArrowUp"] || keys["ArrowDown"] || keys["w"] || keys["s"]) {
        // no-op — fall naturally
      }
    }

    // ── Spawn barrels ──
    s.throwTimer++;
    if (s.throwTimer >= s.throwInterval) {
      s.throwTimer = 0;
      s.barrels.push({//combines two or more arrays alors elle ajoute un nouveau bermil dans la liste
        x: 510, y: 66,
        vx: -diff.barrelRoll, vy: 0,
        angle: 0,
        bstate: "rolling",
        pathStep: 0,
      });
    }

    // ── Update barrels ──
    for (let i = s.barrels.length - 1; i >= 0; i--) {
      const b = s.barrels[i];
      b.angle += 0.1;

      if (b.bstate === "rolling") {
        b.x += b.vx;
        if (b.pathStep < BARREL_PATH.length) {
          const step = BARREL_PATH[b.pathStep];
          const reached = b.vx < 0 ? b.x <= step.enterX : b.x >= step.enterX;
          if (reached) {
            const ladder = LADDERS_DATA[step.ladderIdx];
            b.x = ladder.x + ladder.w / 2;
            b.vx = 0;
            b.vy = diff.barrelDescend;
            b.bstate = "descending";
          }
        }
      } else if (b.bstate === "descending") {
        b.y += b.vy;
        if (b.pathStep < BARREL_PATH.length) {
          const step = BARREL_PATH[b.pathStep];
          if (b.y + 14 >= step.landY) {
            b.y = step.landY - 14;
            b.vy = 0;
            b.pathStep++;
            if (b.pathStep >= BARREL_PATH.length) {
              b.vx = -diff.barrelRoll;
              b.bstate = "rolling";
            } else {//not rolling means on ladder
              b.vx = BARREL_PATH[b.pathStep].enterX > b.x
                ? diff.barrelRoll : -diff.barrelRoll;
              b.bstate = "rolling";
            }
          }
        }
      }

      // ── Hit detection ──
      if (Math.abs(b.x - (p.x + 14)) < 22 && Math.abs(b.y - (p.y + 19)) < 26) {
        s.lives--;
        s.barrels.splice(i, 1);
        if (s.lives <= 0) {
          s.status = "gameover";
        } else {
          s.status = "dead";
          s.overlayTimer = 90;
          resetPlayer(); // clears s.barrels — break, not continue
        }
        syncUI();
        break; // stop iterating: array is either cleared or game is over
      }

      // ── Off screen ──
      if (b.x < -60 || b.x > CANVAS_W + 60 || b.y > CANVAS_H + 60) {
        s.barrels.splice(i, 1);
      }
    }

    // ── Win condition ── (reach top platform on level 3)
    if (p.x > 490 && p.y < 90 && p.x < 590) {
      s.score += 100 * s.level;
      
      if (s.level < 3) {
        s.level++;
        updateDifficulty(); // Apply new difficulty values for next level
        s.status = "levelup";
        s.overlayTimer = 100;
        resetPlayer(); // Clear barrels for fresh start on new level
      } else {
        // LEVEL 3 REACHED = WIN! 🎉
        s.score += 200; // Bonus for winning
        s.score += (state.lives-1)*10;//les coeurs qui restent on un score aussi donc max 820
        s.status = "gameover"; // Reuse modal with win message
      }
      syncUI();
    }

    // ── Fall off screen almost impossible during testing but just in case ──
    if (p.y > CANVAS_H + 20) {
      s.lives--;
      if (s.lives <= 0) {
        s.status = "gameover";
      } else {
        s.status = "dead";
        s.overlayTimer = 90;
        resetPlayer();
      }
      syncUI();
    }
  }

  // ── Overlay countdown ──
  if (s.status === "dead" || s.status === "levelup") {
    s.overlayTimer--;
    if (s.overlayTimer <= 0) {
      if (s.status === "levelup") resetPlayer();
      s.status = "playing";
      syncUI();
    }
  }

  // ─── Render ───────────────────────────────────────────────────────────────
  ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);
  drawBackground();

  const theme = PLATFORM_THEMES[s.themeIdx];
  for (const pl of PLATFORMS_DATA) drawPlatform(pl, theme);
  for (const l of LADDERS_DATA)    drawLadder(l);

  drawMonkey(s.throwTimer, s.throwInterval, s.frame);
  for (const b of s.barrels) drawBarrel(b);

  if (s.status !== "idle") {
    const skin = PLAYER_SKINS[s.skinIdx];
    drawPlayer(s.player, skin, s.frame);
    drawHUD(s.score, s.lives, s.level, s.throwTimer, s.throwInterval);
  }

  if (s.status === "idle") drawTitle(s.frame);
  drawOverlay(s.status, s.score, s.level);

  rafId = requestAnimationFrame(loop);
}

// ─── Button handlers ──────────────────────────────────────────────────────────
document.getElementById("btn-start").addEventListener("click", () => {
  if (state.status === "idle" || state.status === "gameover") {
    state.score = 0;
    state.lives = 3;
    state.level = 1;
    state.throwTimer = 0;
    updateDifficulty(); // Reset to level 1 difficulty
    state.frame = 0;
    state.status = "playing";
    resetPlayer();
    syncUI();
  }
});

document.getElementById("btn-reset").addEventListener("click", () => {
  state.status = "idle";
  state.score = 0;
  state.lives = 3;
  state.level = 1;
  state.throwTimer = 0;
  updateDifficulty();
  resetPlayer();
  syncUI();
});

document.getElementById("btn-theme").addEventListener("click", () => {
  state.themeIdx = (state.themeIdx + 1) % PLATFORM_THEMES.length;
});

document.getElementById("btn-skin").addEventListener("click", () => {
  state.skinIdx = (state.skinIdx + 1) % PLAYER_SKINS.length;
});

// ─── Keyboard ────────────────────────────────────────────────────────────────
window.addEventListener("keydown", e => {
  keys[e.key] = true;
  if (["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"," "].includes(e.key)) {
    e.preventDefault();
  }
});
window.addEventListener("keyup", e => { keys[e.key] = false; });

// ─── Start render loop ────────────────────────────────────────────────────────
updateDifficulty(); // Initialize with level 1 values
loop();